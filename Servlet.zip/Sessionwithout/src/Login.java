

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Login
 */
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Login() {
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String user=request.getParameter("user");//ID
	String pass=request.getParameter("pass");
	PrintWriter pw=response.getWriter();
	response.setContentType("text/html");
	if(user.equals(pass)) {
		//response.sendRedirect("RecievingServlet?user="+user);
		
		pw.print("<form action='Second'>");
		pw.print("<input type='hidden' name='user' value='"+user+"'>");//ID
		pw.print("<input type='submit'>");
		pw.print("</form>");
	}
		
	}

}
