

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ContextParam
 */
public class ContextParam extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public ContextParam() {
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw=response.getWriter();
		ServletConfig sc=getServletConfig();
//		String user=sc.getInitParameter("name");
//		pw.print(user);
		
		Enumeration<String> e=sc.getInitParameterNames();
		
		String s="";
		while(e.hasMoreElements()) {
			s=e.nextElement();
			pw.println(sc.getInitParameter(s));
			
		}
		
		
		
		
		
//		ServletContext sc=getServletContext();
		//String user=sc.getInitParameter("password");
		//pw.print(user);
//		Enumeration<String> e=sc.getInitParameterNames();
//		
//		String s="";
//		while(e.hasMoreElements()) {
//			s=e.nextElement();
//			pw.println(sc.getInitParameter(s));
//			
//		}
		
		
		
		
		
	}

}
